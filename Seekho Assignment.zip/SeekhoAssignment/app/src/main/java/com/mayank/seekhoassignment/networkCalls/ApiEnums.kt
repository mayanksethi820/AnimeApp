package com.mayank.seekhoassignment.networkCalls

enum class ApiEnums {
    ANIME
}