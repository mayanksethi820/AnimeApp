package com.mayank.seekhoassignment.data


import com.google.gson.annotations.SerializedName
import com.mayank.seekhoassignment.utils.AbstractModel

data class AnimeDetailResponse(
    @SerializedName("data")
    var `data`: Data?
) {
    data class Data(
        @SerializedName("aired")
        var aired: Aired?,
        @SerializedName("airing")
        var airing: Boolean?,
        @SerializedName("approved")
        var approved: Boolean?,
        @SerializedName("background")
        var background: String?,
        @SerializedName("broadcast")
        var broadcast: Broadcast?,
        @SerializedName("demographics")
        var demographics: List<Demographic?>?,
        @SerializedName("duration")
        var duration: String?,
        @SerializedName("episodes")
        var episodes: Int?,
        @SerializedName("explicit_genres")
        var explicitGenres: List<Any?>?,
        @SerializedName("favorites")
        var favorites: Int?,
        @SerializedName("genres")
        var genres: List<Genre>?,
        @SerializedName("images")
        var images: Images?,
        @SerializedName("licensors")
        var licensors: List<Licensor>?,
        @SerializedName("mal_id")
        var malId: Int?,
        @SerializedName("members")
        var members: Int?,
        @SerializedName("popularity")
        var popularity: Int?,
        @SerializedName("producers")
        var producers: List<Producer>?,
        @SerializedName("rank")
        var rank: Int?,
        @SerializedName("rating")
        var rating: String?,
        @SerializedName("score")
        var score: Double?,
        @SerializedName("scored_by")
        var scoredBy: Int?,
        @SerializedName("season")
        var season: String?,
        @SerializedName("source")
        var source: String?,
        @SerializedName("status")
        var status: String?,
        @SerializedName("studios")
        var studios: List<Studio?>?,
        @SerializedName("synopsis")
        var synopsis: String?,
        @SerializedName("themes")
        var themes: List<Any?>?,
        @SerializedName("title")
        var title: String?,
        @SerializedName("title_english")
        var titleEnglish: String?,
        @SerializedName("title_japanese")
        var titleJapanese: String?,
        @SerializedName("title_synonyms")
        var titleSynonyms: List<String?>?,
        @SerializedName("titles")
        var titles: List<Title?>?,
        @SerializedName("trailer")
        var trailer: Trailer?,
        @SerializedName("type")
        var type: String?,
        @SerializedName("url")
        var url: String?,
        @SerializedName("year")
        var year: Int?
    ) {
        data class Aired(
            @SerializedName("from")
            var from: String?,
            @SerializedName("prop")
            var prop: Prop?,
            @SerializedName("string")
            var string: String?,
            @SerializedName("to")
            var to: String?
        ) {
            data class Prop(
                @SerializedName("from")
                var from: From?,
                @SerializedName("to")
                var to: To?
            ) {
                data class From(
                    @SerializedName("day")
                    var day: Int?,
                    @SerializedName("month")
                    var month: Int?,
                    @SerializedName("year")
                    var year: Int?
                )

                data class To(
                    @SerializedName("day")
                    var day: Int?,
                    @SerializedName("month")
                    var month: Int?,
                    @SerializedName("year")
                    var year: Int?
                )
            }
        }

        data class Broadcast(
            @SerializedName("day")
            var day: String?,
            @SerializedName("string")
            var string: String?,
            @SerializedName("time")
            var time: String?,
            @SerializedName("timezone")
            var timezone: String?
        )

        data class Demographic(
            @SerializedName("mal_id")
            var malId: Int?,
            @SerializedName("name")
            var name: String?,
            @SerializedName("type")
            var type: String?,
            @SerializedName("url")
            var url: String?
        )

        data class Genre(
            @SerializedName("mal_id")
            var malId: Int?,
            @SerializedName("name")
            var name: String?,
            @SerializedName("type")
            var type: String?,
            @SerializedName("url")
            var url: String?
        ) : AbstractModel()

        fun emptyGenres(): Boolean {
            return genres.isNullOrEmpty()
        }

        data class Images(
            @SerializedName("jpg")
            var jpg: Jpg?,
            @SerializedName("webp")
            var webp: Webp?
        ) {
            data class Jpg(
                @SerializedName("image_url")
                var imageUrl: String?,
                @SerializedName("large_image_url")
                var largeImageUrl: String?,
                @SerializedName("small_image_url")
                var smallImageUrl: String?
            )

            data class Webp(
                @SerializedName("image_url")
                var imageUrl: String?,
                @SerializedName("large_image_url")
                var largeImageUrl: String?,
                @SerializedName("small_image_url")
                var smallImageUrl: String?
            )
        }

        data class Licensor(
            @SerializedName("mal_id")
            var malId: Int?,
            @SerializedName("name")
            var name: String?,
            @SerializedName("type")
            var type: String?,
            @SerializedName("url")
            var url: String?
        ) : AbstractModel()

        fun emptyLicensor(): Boolean {
            return licensors.isNullOrEmpty()
        }

        data class Producer(
            @SerializedName("mal_id")
            var malId: Int?,
            @SerializedName("name")
            var name: String?,
            @SerializedName("type")
            var type: String?,
            @SerializedName("url")
            var url: String?
        ) : AbstractModel()

        fun emptyProducer(): Boolean {
            return producers.isNullOrEmpty()
        }

        data class Studio(
            @SerializedName("mal_id")
            var malId: Int?,
            @SerializedName("name")
            var name: String?,
            @SerializedName("type")
            var type: String?,
            @SerializedName("url")
            var url: String?
        )

        data class Title(
            @SerializedName("title")
            var title: String?,
            @SerializedName("type")
            var type: String?
        )

        data class Trailer(
            @SerializedName("embed_url")
            var embedUrl: String?,
            @SerializedName("images")
            var images: Images?,
            @SerializedName("url")
            var url: String?,
            @SerializedName("youtube_id")
            var youtubeId: String?
        ) {
            data class Images(
                @SerializedName("image_url")
                var imageUrl: String?,
                @SerializedName("large_image_url")
                var largeImageUrl: String?,
                @SerializedName("maximum_image_url")
                var maximumImageUrl: String?,
                @SerializedName("medium_image_url")
                var mediumImageUrl: String?,
                @SerializedName("small_image_url")
                var smallImageUrl: String?
            )
        }
    }
}