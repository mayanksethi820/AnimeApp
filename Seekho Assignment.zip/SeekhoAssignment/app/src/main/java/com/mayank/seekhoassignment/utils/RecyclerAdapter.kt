package com.mayank.seekhoassignment.utils

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.annotation.LayoutRes
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.RecyclerView
import com.mayank.seekhoassignment.BR
import com.mayank.seekhoassignment.R

class RecyclerAdapter<T : AbstractModel>(
    @LayoutRes var layoutId: Int, private var animation: Boolean = false
) : RecyclerView.Adapter<RecyclerAdapter.VH<T>>() {

    private var inflater: LayoutInflater? = null
    private val items by lazy { mutableListOf<T>() }
    private var onItemClick: OnItemClick? = null

    @SuppressLint("NotifyDataSetChanged")
    fun addItems(item: List<T>) {
        this.items.clear()
        this.items.addAll(item)
        notifyDataSetChanged()
    }

    fun setOnItemClick(onItemClick: OnItemClick?) {
        this.onItemClick = onItemClick
    }

    class VH<T : AbstractModel>(private val binding: ViewDataBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(model: T) {
            binding.setVariable(BR.model, model)
            binding.executePendingBindings()
        }
    }


    fun interface OnItemClick {
        fun onClick(view: View, viewHolder: RecyclerView.ViewHolder, item: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH<T> {
        val layoutInflater = inflater ?: LayoutInflater.from(parent.context)
        val binding =
            DataBindingUtil.inflate<ViewDataBinding>(layoutInflater, layoutId, parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH<T>, position: Int) {
        val model = items[position]
        model.viewHolder = holder
        model.position = position

        onItemClick.let {
            model.onItemClick = it
        }

        holder.bind(model)
    }

    override fun getItemCount(): Int = items.size

}