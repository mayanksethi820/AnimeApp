package com.mayank.seekhoassignment.networkCalls

import android.util.Log
import com.mayank.seekhoassignment.MainActivity
import com.mayank.seekhoassignment.utils.isNetworkAvailable
import com.mayank.seekhoassignment.utils.showNegativeAlerter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import org.json.JSONObject
import retrofit2.Response
import javax.inject.Inject

class Repository @Inject constructor(
    private val retrofitApi: RetrofitApi,
    private val cacheUtil: CacheUtil
) {
    fun <T> makeCall(
        apiKey: ApiEnums,
        loader: Boolean,
        saveInCache: Boolean,
        requestProcessor: ApiProcessor<Response<T>>
    ) {
        val activity = MainActivity.context?.get()!!
        if (cacheUtil.snapshot().containsKey(apiKey)) {
            Log.d("cacheUtil", "========${cacheUtil[apiKey]}")
            requestProcessor.onResponse(cacheUtil[apiKey] as Response<T>)
            return
        }
        if (!activity.isNetworkAvailable()) {
            activity.showNegativeAlerter("Your device is offline")
            return
        }

        val dataResponse: Flow<Response<Any>> = flow {
            val response =
                requestProcessor.sendRequest(retrofitApi) as Response<Any>
            emit(response)
        }.flowOn(Dispatchers.IO)

        CoroutineScope(Dispatchers.Main).launch {
            dataResponse.catch { exception ->
                exception.printStackTrace()
                activity.showNegativeAlerter(exception.message ?: "")
            }.collect { response ->
                when {
                    response.code() in 100..199 -> {
                        /**Informational*/
                        requestProcessor.onError(
                            "Some error occurred"
                        )
                        activity.showNegativeAlerter(
                            "Some error occurred"
                        )
                    }

                    response.isSuccessful -> {
                        /**Success*/
                        Log.d("successBody", "====${response.body()}")
                        if (saveInCache)
                            cacheUtil.put(apiKey, response)
                        requestProcessor.onResponse(response as Response<T>)
                    }

                    response.code() in 300..399 -> {
                        /**Redirection*/
                        requestProcessor.onError(
                            "Some error occurred"
                        )
                        activity.showNegativeAlerter(
                            "Some error occurred"
                        )
                    }

                    response.code() == 400 -> {
                        try {
                            val errorBody = response.errorBody()?.string()
                            val errorJson = JSONObject(errorBody)
                            val errorsArray = errorJson.getJSONArray("errors")

                            if (errorsArray.length() > 0) {
                                val errorMessage = errorsArray.getJSONObject(0).getString("message")
                                activity.showNegativeAlerter(errorMessage)
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    response.code() == 412 -> {
                        try {
                            val errorBody = response.errorBody()?.string()
                            val errorJson = JSONObject(errorBody)
                            val errorsArray = errorJson.getJSONArray("errors")

                            if (errorsArray.length() > 0) {
                                val errorMessage = errorsArray.getJSONObject(0).getString("message")
                                activity.showNegativeAlerter(errorMessage)
                                // Now you can use errorMessage as needed, e.g., show it in an alert
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    response.code() == 401 -> {
                        requestProcessor.onError(
                            "Some error occurred"
                        )
                        activity.showNegativeAlerter(
                            "Some error occurred"
                        )
                    }

                    response.code() == 404 -> {
                        /**Page Not Found*/
                        requestProcessor.onError(
                            "Some error occurred"
                        )
                        activity.showNegativeAlerter(
                            "Some error occurred"
                        )
                    }

                    response.code() in 500..599 -> {
                        /**ServerErrors*/
                        requestProcessor.onError(
                            "Some error occurred"
                        )
                        activity.showNegativeAlerter(
                            "Some error occurred"
                        )
                    }

                    else -> {
                        /**ClientErrors*/
                        val res = response.errorBody()!!.string()
                        val jsonObject = JSONObject(res)
                        when {
                            jsonObject.has("message") -> {
                                requestProcessor.onError(jsonObject.getString("message"))

                                if (!jsonObject.getString("message").equals("Data not found", true))
                                    activity
                                        .showNegativeAlerter(jsonObject.getString("message"))
                            }

                            else -> {
                                requestProcessor.onError(
                                    "Some error occurred"
                                )
                                activity.showNegativeAlerter(
                                    "Some error occurred"
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
