package com.mayank.seekhoassignment.ui.home

import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mayank.seekhoassignment.R
import com.mayank.seekhoassignment.data.JikanApiResponse
import com.mayank.seekhoassignment.networkCalls.ApiEnums
import com.mayank.seekhoassignment.networkCalls.ApiProcessor
import com.mayank.seekhoassignment.networkCalls.Repository
import com.mayank.seekhoassignment.networkCalls.RetrofitApi
import com.mayank.seekhoassignment.utils.RecyclerAdapter
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private var repository: Repository) : ViewModel() {

    var animeListAdapter: RecyclerAdapter<JikanApiResponse.Data> =
        RecyclerAdapter(R.layout.adapter_home_anime_list)
    var animeList: ArrayList<JikanApiResponse.Data> = ArrayList()

    var showShimmer: ObservableField<Boolean> = ObservableField(false)

    init {
        fetchAnimeData()
    }

    private fun fetchAnimeData() = viewModelScope.launch {
        showShimmer.set(true)
        repository.makeCall(
            apiKey = ApiEnums.ANIME,
            loader = false,
            saveInCache = false,
            requestProcessor = object : ApiProcessor<Response<JikanApiResponse>> {
                override suspend fun sendRequest(retrofitApi: RetrofitApi): Response<JikanApiResponse> {
                    return retrofitApi.getAnimeList()
                }

                override fun onResponse(res: Response<JikanApiResponse>) {
                    res.body()?.data?.map {
                        animeList.add(it)
                    }
                    animeListAdapter.addItems(animeList)
                    showShimmer.set(false)
                }
            })
    }
}