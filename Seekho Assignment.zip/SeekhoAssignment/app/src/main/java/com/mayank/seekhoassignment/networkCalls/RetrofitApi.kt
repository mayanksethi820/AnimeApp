package com.mayank.seekhoassignment.networkCalls

import com.mayank.seekhoassignment.data.AnimeDetailResponse
import com.mayank.seekhoassignment.data.JikanApiResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface RetrofitApi {

    @GET("top/anime")
    suspend fun getAnimeList(): Response<JikanApiResponse>

    @GET("anime/{id}")
    suspend fun getAnimeDetails(@Path("id") id: String): Response<AnimeDetailResponse>
}