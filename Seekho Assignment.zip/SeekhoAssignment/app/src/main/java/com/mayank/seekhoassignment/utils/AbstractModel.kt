package com.mayank.seekhoassignment.utils

import androidx.recyclerview.widget.RecyclerView
import kotlinx.parcelize.RawValue

abstract class AbstractModel {
    var position: Int = -1

    @Transient
    var viewHolder: RecyclerView.ViewHolder? = null

    @Transient
    var onItemClick: @RawValue RecyclerAdapter.OnItemClick? = null

    fun getRVPosition(): Int {
        return viewHolder?.absoluteAdapterPosition ?: -1
    }
}