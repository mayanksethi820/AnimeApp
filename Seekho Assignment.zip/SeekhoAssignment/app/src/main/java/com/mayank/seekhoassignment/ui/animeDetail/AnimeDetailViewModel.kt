package com.mayank.seekhoassignment.ui.animeDetail

import androidx.databinding.ObservableField
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mayank.seekhoassignment.R
import com.mayank.seekhoassignment.data.AnimeDetailResponse
import com.mayank.seekhoassignment.networkCalls.ApiEnums
import com.mayank.seekhoassignment.networkCalls.ApiProcessor
import com.mayank.seekhoassignment.networkCalls.Repository
import com.mayank.seekhoassignment.networkCalls.RetrofitApi
import com.mayank.seekhoassignment.utils.RecyclerAdapter
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class AnimeDetailViewModel @Inject constructor(
    private var repository: Repository,
    private val savedStateHandle: SavedStateHandle
) : ViewModel() {

    var animeDetailsData: ObservableField<AnimeDetailResponse> =
        ObservableField<AnimeDetailResponse>()
    var genreListAdapter: RecyclerAdapter<AnimeDetailResponse.Data.Genre> =
        RecyclerAdapter(R.layout.anime_genre_list)
    var producerListAdapter: RecyclerAdapter<AnimeDetailResponse.Data.Producer> =
        RecyclerAdapter(R.layout.anime_producers_list)
    var licensorListAdapter: RecyclerAdapter<AnimeDetailResponse.Data.Licensor> =
        RecyclerAdapter(R.layout.anime_licensors_list)
    private val args = savedStateHandle.get<String>("id")

    var showShimmer: ObservableField<Boolean> = ObservableField(false)

    init {
        fetchAnimeDetails()
    }

    private fun fetchAnimeDetails() = viewModelScope.launch {
        showShimmer.set(true)
        repository.makeCall(
            apiKey = ApiEnums.ANIME,
            loader = false,
            saveInCache = false,
            requestProcessor = object : ApiProcessor<Response<AnimeDetailResponse>> {
                override suspend fun sendRequest(retrofitApi: RetrofitApi): Response<AnimeDetailResponse> {
                    return retrofitApi.getAnimeDetails(args ?: "")
                }

                override fun onResponse(res: Response<AnimeDetailResponse>) {
                    showShimmer.set(false)
                    animeDetailsData.set(res.body())
                    res.body()?.data?.genres?.let { genreListAdapter.addItems(it) }
                    res.body()?.data?.producers?.let { producerListAdapter.addItems(it) }
                    res.body()?.data?.licensors?.let { licensorListAdapter.addItems(it) }
                }
            })
    }
}