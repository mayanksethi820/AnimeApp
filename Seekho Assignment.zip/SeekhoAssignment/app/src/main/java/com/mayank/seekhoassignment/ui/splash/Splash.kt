package com.mayank.seekhoassignment.ui.splash

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.mayank.seekhoassignment.R
import com.mayank.seekhoassignment.databinding.SplashBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class Splash : Fragment(R.layout.splash) {

    private lateinit var binding: SplashBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = SplashBinding.inflate(inflater, container, false)
        customNavigate()
        return binding.root
    }

    private fun customNavigate() {
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                view?.findNavController()?.navigate(SplashDirections.splashToHome())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, 2000)
    }

}