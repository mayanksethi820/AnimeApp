package com.mayank.seekhoassignment.utils

import android.graphics.drawable.Drawable
import android.text.Html
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

object BindingAdapters {

    @BindingAdapter(value = ["setRecyclerAdapter"], requireAll = false)
    @JvmStatic
    fun setRecyclerAdapter(
        recyclerView: RecyclerView,
        adapter: RecyclerView.Adapter<*>?,
    ) {
        recyclerView.adapter = adapter
    }

    @BindingAdapter(value = ["setImageUrl", "placeHolder"], requireAll = false)
    @JvmStatic
    fun setImageUrl(
        imageView: ImageView,
        url: String?,
        placeHolder: Drawable? = null,
    ) {
        Log.e("ImageUrlIs", "$url")

        when {
            url.isNullOrEmpty() && placeHolder == null -> return
            url.isNullOrEmpty() && placeHolder != null -> Glide.with(imageView).load(placeHolder)
                .into(imageView)

            !url.isNullOrEmpty() && placeHolder == null -> Glide.with(imageView).load(url)
                .into(imageView)

            !url.isNullOrEmpty() && placeHolder != null -> Glide.with(imageView).load(url)
                .placeholder(placeHolder).error(placeHolder).into(imageView)
        }
    }

    @JvmStatic
    @BindingAdapter("scoreTextFormatted")
    fun setScoreFormatted(textView: TextView, score: Double?) {
        val color = when {
            score == null -> "#FFFFFF" // fallback color
            score < 4.0 -> "#FF3B30"    // red
            score < 7.0 -> "#FFBB33"   // yellow
            else -> "#4CAF50"          // green
        }

        val formatted = "Score <font color='$color'>${score ?: "N/A"}</font>"
        textView.text = Html.fromHtml(formatted, Html.FROM_HTML_MODE_LEGACY)
    }
}